## esoTalk – EmoticonsPlus plugin

- Extends Emoticons plugin with an add emoticon button on the formatting toolbar.

### Installation

Browse to your esoTalk plugin directory:
```
cd WEB_ROOT_DIR/addons/plugins/
```

Clone the EmoticonsPlus plugin repo into the plugin directory:
```
git clone git@github.com:esoTalk-plugins/EmoticonsPlus.git EmoticonsPlus
```

Chown the EmoticonsPlus plugin folder to the right web user:
```
chown -R apache:apache EmoticonsPlus/
```
