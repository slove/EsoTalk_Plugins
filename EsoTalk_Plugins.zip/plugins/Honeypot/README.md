## esoTalk – Honeypot plugin

- Spam prevention with invisible form fields.

### Release Note

- esoTalk version 1.0.0g4 and beyond is required!

### Installation

Browse to your esoTalk plugin directory:
```
cd WEB_ROOT_DIR/addons/plugins/
```

Clone the Honeypot plugin repo into the plugin directory:
```
git clone git@github.com:tvb/Honeypot.git Honeypot
```

Chown the Honeypot plugin folder to the right web user:
```
chown -R apache:apache Honeypot/
```
