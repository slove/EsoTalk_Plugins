# AntiAdBlocker Plugin

Allows to hide Content if AdBlocker is active.

## Installation

Download the AntiAdBlocker plugin repo into your esoTalk plugin directory:

	cd ESOTALK_DIR/addons/plugins/

Navigate to the the admin/plugins page and activate the AntiAdBlocker plugin.

## Translation

Not needed but

You can create `definitions.AntiAdBlocker.php` in your language pack with the following definitions:

  $definitions["AntiAdBlocker"] = "Please disable your ad blocker!";
