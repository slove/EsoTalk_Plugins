# User Since Plugin

Shows the year that the user joined the forum on their posts.

## Installation

[Download](https://github.com/esotalk/UserSince/archive/master.zip) or clone the User Since plugin repo into your esoTalk plugin directory:

	cd ESOTALK_DIR/addons/plugins/
	git clone git@github.com:esotalk/UserSince.git UserSince

Navigate to the the admin/plugins page and activate the User Since plugin.

## Translation

Create `definitions.UserSince.php` in your language pack with the following definitions:

	$definitions["User since %s"] = "User since %s";
