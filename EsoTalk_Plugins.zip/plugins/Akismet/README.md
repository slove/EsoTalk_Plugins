# esotalk-akismet
Anti-spammer plugin for esotalk
