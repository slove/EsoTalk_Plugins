MSCaptcha
=========

Just simple captcha for esoTalk


![Preview 1](http://esotalk.org/forum/attachment/54092490367b7_captcha.png)
