# ReportBug
This is a plugin for the esoTalk forum software, what it does is very simple, it creates a footer option called "Report Bug", this plugin is very simple and shouldn't really need to be edited unless you wish for something more "flashy".

# Installation
Install to >your directory>addons>plugin then unzip and this is the very important part rename the plugin ReportBug (Normally Github adds "-master" in the plugin's name which will make the plugin unusable.

# Manual Editing
On line 26 of the plugin.php you'll see "mailto:example@email.com" you'll have to add your own email to this line.
