2.1
===

- Moved to forum version g4 (**previous versions are no longer supported**)
- Fixed small bugs

2.0.2
=====

- Reworked plugin settings (to move your existing settings see [this](https://bitbucket.org/alex-dev/opauthconnect/src/83e131e0b885/README.md))
- Fixed small bugs. Thanks to [Tristan](http://esotalk.org/forum/29-social-networking-integration/64#p3094)

2.0.1
=====

- Added Vkontakte support
- Updated 'social accounts' page appearance

2.0
===

- Fully reworked plugin logic
- Updated plugin settings
- Added possibility to define password and username during registration process
- Added email template for automatically generated password
- Added possibility to configure emails subjects
- Updated emails templates
- Added 'social accounts' page to user settings, where users can view/manage their connected social accounts
- Added possibility to unlink own social accounts (configurable)