# EsoTalk Description Pluigin
Adds a description next to Forum Title.

## Installation

Upload plugin to addons/plugin folder.

Navigate to the the admin/plugins page and activate the Forum Description plugin.

## Copy the following css code to `base.css`


/* Description */
.item-description{
	font-size: 14px;
	color: #888888;
	margin:0; display:inline;
	float: left !important;
	padding-top: 11px;
	top: 12px;
	position: absolute !important;
	margin-left: -10px;
	overflow: hidden;
	
}



# Done